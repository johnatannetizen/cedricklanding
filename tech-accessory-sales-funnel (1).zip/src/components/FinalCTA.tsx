import { useState, useEffect } from "react";

const WA_NUMBER = "573016515466";

export default function FinalCTA() {
  const [time, setTime] = useState({ hours: 2, minutes: 47, seconds: 33 });

  useEffect(() => {
    const interval = setInterval(() => {
      setTime((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const pad = (n: number) => String(n).padStart(2, "0");

  const waLink = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent("Hola Cedrick Tech, quiero aprovechar la oferta especial 🔥")}`;

  return (
    <section className="py-24 px-4 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute inset-0 bg-gradient-to-br from-orange-500/10 via-pink-500/10 to-purple-500/10" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-orange-500/5 via-transparent to-transparent" />

      <div className="relative max-w-4xl mx-auto text-center">
        {/* Urgency badge */}
        <div className="inline-flex items-center gap-2 bg-red-500/20 border border-red-500/40 text-red-400 text-sm font-bold px-5 py-2 rounded-full mb-8 animate-pulse">
          ⚠️ ¡ÚLTIMA OPORTUNIDAD! Esta oferta expira pronto
        </div>

        <h2 className="text-4xl sm:text-5xl md:text-6xl font-black mb-6 leading-tight">
          <span className="text-white">¿Listo para dar el</span>
          <br />
          <span className="bg-gradient-to-r from-orange-400 via-pink-500 to-purple-500 bg-clip-text text-transparent">
            siguiente paso?
          </span>
        </h2>

        <p className="text-gray-300 text-lg sm:text-xl max-w-2xl mx-auto mb-10">
          No dejes pasar esta oportunidad. Los precios especiales terminan pronto y el stock es limitado.
          <strong className="text-orange-400"> ¡Asegura el tuyo ahora!</strong>
        </p>

        {/* Countdown */}
        <div className="flex justify-center gap-4 mb-10">
          {[
            { value: pad(time.hours), label: "Horas" },
            { value: pad(time.minutes), label: "Minutos" },
            { value: pad(time.seconds), label: "Segundos" },
          ].map((item, i) => (
            <div key={i} className="text-center">
              <div className="bg-gradient-to-b from-orange-500 to-pink-600 text-white font-black text-3xl sm:text-4xl w-20 h-20 sm:w-24 sm:h-24 rounded-2xl flex items-center justify-center shadow-lg shadow-orange-500/30">
                {item.value}
              </div>
              <p className="text-gray-500 text-xs mt-2 font-semibold uppercase tracking-widest">{item.label}</p>
            </div>
          ))}
        </div>

        {/* Main CTA */}
        <a
          href={waLink}
          target="_blank"
          rel="noopener noreferrer"
          className="group inline-flex items-center gap-3 bg-gradient-to-r from-orange-500 via-pink-600 to-purple-600 hover:from-orange-400 hover:via-pink-500 hover:to-purple-500 text-white font-black text-xl px-12 py-5 rounded-full transition-all duration-200 shadow-2xl shadow-orange-500/40 hover:scale-105 hover:shadow-orange-500/60 mb-6"
        >
          <svg className="w-7 h-7 group-hover:scale-110 transition-transform" fill="currentColor" viewBox="0 0 24 24">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
          </svg>
          ¡Comprar Ahora por WhatsApp!
        </a>

        <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-500">
          <span className="flex items-center gap-1"><span className="text-green-400">✓</span> Sin compromiso</span>
          <span className="flex items-center gap-1"><span className="text-green-400">✓</span> Respuesta inmediata</span>
          <span className="flex items-center gap-1"><span className="text-green-400">✓</span> Pago seguro</span>
          <span className="flex items-center gap-1"><span className="text-green-400">✓</span> Garantía 12 meses</span>
        </div>

        {/* Urgency text */}
        <div className="mt-8 bg-gradient-to-r from-orange-500/10 to-pink-500/10 border border-orange-500/20 rounded-2xl px-8 py-5 inline-block">
          <p className="text-orange-300 font-semibold">
            🔥 <strong>47 personas</strong> están viendo esta oferta ahora mismo. 
            Stock limitado: solo quedan <strong className="text-white">23 unidades</strong> disponibles.
          </p>
        </div>
      </div>
    </section>
  );
}
