const WA_NUMBER = "573016515466";

const products = [
  {
    id: 1,
    name: "Audífonos TWS Pro X",
    category: "Audífonos Bluetooth",
    image: "/images/product-earbuds.jpg",
    price: "129.900",
    oldPrice: "219.900",
    discount: "41%",
    badge: "🔥 Más Vendido",
    stars: 5,
    reviews: 389,
    features: ["Cancelación de ruido activa", "40h de batería", "Resistente al agua IPX5", "Carga rápida 15 min"],
    color: "from-orange-500 to-pink-600",
    msg: "Hola, quiero comprar los Audífonos TWS Pro X 🎧",
  },
  {
    id: 2,
    name: "Smartwatch Ultra S3",
    category: "Smartwatches",
    image: "/images/product-smartwatch.jpg",
    price: "189.900",
    oldPrice: "299.900",
    discount: "37%",
    badge: "⚡ Súper Oferta",
    stars: 5,
    reviews: 241,
    features: ["Monitor cardíaco 24/7", "GPS integrado", "100+ modos deportivos", "Pantalla AMOLED HD"],
    color: "from-blue-500 to-purple-600",
    msg: "Hola, quiero comprar el Smartwatch Ultra S3 ⌚",
  },
  {
    id: 3,
    name: "Cargador Inalámbrico 4 en 1",
    category: "Cargadores",
    image: "/images/product-charger.jpg",
    price: "89.900",
    oldPrice: "149.900",
    discount: "40%",
    badge: "🆕 Nuevo",
    stars: 4,
    reviews: 158,
    features: ["Carga hasta 4 dispositivos", "65W carga ultra rápida", "Compatible con todos los phones", "LED indicador"],
    color: "from-green-500 to-teal-600",
    msg: "Hola, quiero comprar el Cargador Inalámbrico 4 en 1 🔌",
  },
  {
    id: 4,
    name: "Cable Braided Premium",
    category: "Cables & Conectores",
    image: "/images/product-cable.jpg",
    price: "39.900",
    oldPrice: "69.900",
    discount: "43%",
    badge: "💎 Premium",
    stars: 5,
    reviews: 512,
    features: ["Triple refuerzo anti-quiebre", "Carga y datos 480 Mbps", "2 metros de largo", "USB-C / Lightning / MicroUSB"],
    color: "from-indigo-500 to-blue-600",
    msg: "Hola, quiero comprar el Cable Braided Premium 🔗",
  },
  {
    id: 5,
    name: "Power Bank 20.000 mAh",
    category: "Baterías Portátiles",
    image: "/images/product-powerbank.jpg",
    price: "99.900",
    oldPrice: "169.900",
    discount: "41%",
    badge: "⚡ Alta Demanda",
    stars: 5,
    reviews: 302,
    features: ["20.000 mAh de capacidad", "Carga 3 dispositivos a la vez", "Display LED de batería", "Ultra delgado y ligero"],
    color: "from-yellow-500 to-orange-500",
    msg: "Hola, quiero comprar el Power Bank 20.000 mAh 🔋",
  },
];

function StarRating({ stars, reviews }: { stars: number; reviews: number }) {
  return (
    <div className="flex items-center gap-1.5">
      <div className="flex">
        {Array.from({ length: 5 }).map((_, i) => (
          <svg
            key={i}
            className={`w-4 h-4 ${i < stars ? "text-yellow-400" : "text-gray-600"}`}
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        ))}
      </div>
      <span className="text-gray-400 text-xs">({reviews})</span>
    </div>
  );
}

export default function Products() {
  return (
    <section id="productos" className="py-24 px-4 max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <div className="inline-flex items-center gap-2 bg-orange-500/20 border border-orange-500/30 text-orange-400 text-sm font-semibold px-4 py-1.5 rounded-full mb-4">
          🛒 Catálogo Exclusivo
        </div>
        <h2 className="text-4xl sm:text-5xl font-black mb-4">
          <span className="text-white">Nuestros </span>
          <span className="bg-gradient-to-r from-orange-400 to-pink-500 bg-clip-text text-transparent">
            Productos Estrella
          </span>
        </h2>
        <p className="text-gray-400 text-lg max-w-2xl mx-auto">
          Selección curada de los mejores accesorios tech. Calidad garantizada, precios imbatibles.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {products.map((product) => {
          const waLink = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(product.msg)}`;
          return (
            <div
              key={product.id}
              className="group bg-gradient-to-b from-white/5 to-white/[0.02] border border-white/10 rounded-3xl overflow-hidden hover:border-orange-500/40 transition-all duration-300 hover:shadow-2xl hover:shadow-orange-500/10 hover:-translate-y-1"
            >
              {/* Image */}
              <div className="relative overflow-hidden h-56">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className={`absolute inset-0 bg-gradient-to-t from-[#0a0a0f] via-transparent to-transparent opacity-60`} />
                <div className="absolute top-3 left-3 bg-gradient-to-r from-orange-500 to-pink-600 text-white text-xs font-bold px-3 py-1 rounded-full">
                  {product.badge}
                </div>
                <div className="absolute top-3 right-3 bg-green-500 text-white text-xs font-black px-3 py-1 rounded-full">
                  -{product.discount}
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <p className="text-orange-400 text-xs font-semibold uppercase tracking-widest mb-1">{product.category}</p>
                <h3 className="text-white font-black text-xl mb-2">{product.name}</h3>
                <StarRating stars={product.stars} reviews={product.reviews} />

                <ul className="mt-4 space-y-1.5 mb-5">
                  {product.features.map((f, i) => (
                    <li key={i} className="flex items-center gap-2 text-gray-400 text-sm">
                      <svg className="w-4 h-4 text-green-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      {f}
                    </li>
                  ))}
                </ul>

                <div className="flex items-end justify-between mb-4">
                  <div>
                    <p className="text-gray-500 text-sm line-through">${product.oldPrice}</p>
                    <p className="text-3xl font-black text-white">${product.price}</p>
                    <p className="text-green-400 text-xs font-semibold">COP · IVA incluido</p>
                  </div>
                  <div className="text-right">
                    <p className="text-green-400 text-sm font-bold">✓ En stock</p>
                    <p className="text-gray-500 text-xs">Envío inmediato</p>
                  </div>
                </div>

                <a
                  href={waLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full flex items-center justify-center gap-2 bg-gradient-to-r ${product.color} hover:opacity-90 text-white font-bold py-3.5 rounded-2xl transition-all duration-200 hover:scale-[1.02] shadow-lg text-sm`}
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                  </svg>
                  ¡Pedir por WhatsApp!
                </a>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom CTA */}
      <div className="text-center mt-12">
        <p className="text-gray-400 mb-4">¿No encontraste lo que buscas? Tenemos más productos disponibles</p>
        <a
          href={`https://wa.me/${WA_NUMBER}?text=${encodeURIComponent("Hola Cedrick Tech, quisiera ver el catálogo completo de productos 📦")}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 border-2 border-orange-500 text-orange-400 hover:bg-orange-500 hover:text-white font-bold px-8 py-3 rounded-full transition-all duration-200"
        >
          Ver Catálogo Completo →
        </a>
      </div>
    </section>
  );
}
