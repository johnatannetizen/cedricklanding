const testimonials = [
  {
    name: "Valentina R.",
    city: "Medellín",
    avatar: "VR",
    color: "from-pink-500 to-rose-600",
    product: "Audífonos TWS Pro X",
    rating: 5,
    text: "¡Increíble servicio! Los audífonos llegaron en perfecto estado y en solo 2 días. La calidad de sonido es espectacular, superaron mis expectativas. 100% recomendados 🎧",
  },
  {
    name: "Andrés M.",
    city: "Bogotá",
    avatar: "AM",
    color: "from-blue-500 to-indigo-600",
    product: "Smartwatch Ultra S3",
    rating: 5,
    text: "Compré el smartwatch y quedé sorprendido con la pantalla AMOLED. Cedrick Tech respondió súper rápido por WhatsApp y me asesoraron perfectamente. ¡Volveré a comprar!",
  },
  {
    name: "Camila T.",
    city: "Cali",
    avatar: "CT",
    color: "from-purple-500 to-violet-600",
    product: "Cargador Inalámbrico",
    rating: 5,
    text: "El proceso de compra fue facilísimo. Escribí por WhatsApp, me enviaron los detalles y en 3 días tenía mi cargador en casa. El producto es de excelente calidad 🔌",
  },
  {
    name: "Juan P.",
    city: "Barranquilla",
    avatar: "JP",
    color: "from-green-500 to-emerald-600",
    product: "Power Bank 20.000 mAh",
    rating: 5,
    text: "Llevé el power bank en un viaje largo y nunca me quedé sin batería. Vale cada peso. Además, cuando tuve una duda, Cedrick Tech me respondió en menos de 2 minutos ⚡",
  },
  {
    name: "María F.",
    city: "Bucaramanga",
    avatar: "MF",
    color: "from-orange-500 to-amber-600",
    product: "Cable Braided Premium",
    rating: 5,
    text: "Por fin un cable que no se daña! Llevo 6 meses usándolo todos los días y está perfecto. Además el precio era increíble. Definitivamente compraré más productos 💯",
  },
  {
    name: "Carlos B.",
    city: "Pereira",
    avatar: "CB",
    color: "from-teal-500 to-cyan-600",
    product: "Audífonos TWS Pro X",
    rating: 5,
    text: "La cancelación de ruido es real y funciona increíble. Los uso para trabajar y estudiar. Cedrick Tech me dio una asesoría personalizada. ¡El mejor lugar para comprar tech!",
  },
];

function StarRating({ count }: { count: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: count }).map((_, i) => (
        <span key={i} className="text-yellow-400 text-sm">★</span>
      ))}
    </div>
  );
}

export default function Testimonials() {
  return (
    <section id="testimonios" className="py-24 px-4 bg-gradient-to-b from-[#0a0a0f] via-[#0e0e1c] to-[#0a0a0f]">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-yellow-500/20 border border-yellow-500/30 text-yellow-400 text-sm font-semibold px-4 py-1.5 rounded-full mb-4">
            ⭐ Clientes que nos aman
          </div>
          <h2 className="text-4xl sm:text-5xl font-black mb-4">
            <span className="text-white">Lo que dicen </span>
            <span className="bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
              nuestros clientes
            </span>
          </h2>
          <p className="text-gray-400 text-lg max-w-xl mx-auto">
            Más de 5.000 personas ya confían en Cedrick Tech. Ellos lo dicen mejor que nosotros.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={i}
              className="bg-gradient-to-b from-white/[0.07] to-white/[0.02] border border-white/10 rounded-2xl p-6 hover:border-yellow-500/30 transition-all duration-300 hover:-translate-y-1"
            >
              {/* Header */}
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${t.color} flex items-center justify-center text-white font-black text-sm flex-shrink-0`}>
                  {t.avatar}
                </div>
                <div>
                  <p className="text-white font-bold">{t.name}</p>
                  <p className="text-gray-500 text-xs">📍 {t.city}</p>
                </div>
                <div className="ml-auto">
                  <StarRating count={t.rating} />
                </div>
              </div>

              {/* Product tag */}
              <div className="inline-flex items-center gap-1 bg-orange-500/15 border border-orange-500/25 text-orange-400 text-xs px-3 py-1 rounded-full mb-3 font-medium">
                🛒 {t.product}
              </div>

              {/* Text */}
              <p className="text-gray-300 text-sm leading-relaxed">"{t.text}"</p>

              {/* Verified badge */}
              <div className="flex items-center gap-1 mt-4 text-green-400 text-xs font-semibold">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Compra verificada
              </div>
            </div>
          ))}
        </div>

        {/* Trust metrics */}
        <div className="mt-12 flex flex-wrap justify-center gap-6 text-sm">
          <div className="flex items-center gap-2 bg-white/5 border border-white/10 px-5 py-3 rounded-full text-gray-300">
            <span className="text-yellow-400 text-lg">⭐</span>
            <span><strong className="text-white">4.9/5</strong> · Calificación general</span>
          </div>
          <div className="flex items-center gap-2 bg-white/5 border border-white/10 px-5 py-3 rounded-full text-gray-300">
            <span className="text-green-400">✓</span>
            <span><strong className="text-white">98%</strong> · Tasa de satisfacción</span>
          </div>
          <div className="flex items-center gap-2 bg-white/5 border border-white/10 px-5 py-3 rounded-full text-gray-300">
            <span>💬</span>
            <span><strong className="text-white">+2.000</strong> · Reseñas positivas</span>
          </div>
        </div>
      </div>
    </section>
  );
}
