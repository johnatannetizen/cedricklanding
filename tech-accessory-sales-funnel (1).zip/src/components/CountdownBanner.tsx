import { useState, useEffect } from "react";

export default function CountdownBanner() {
  const [time, setTime] = useState({ hours: 4, minutes: 59, seconds: 59 });

  useEffect(() => {
    const interval = setInterval(() => {
      setTime((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const pad = (n: number) => String(n).padStart(2, "0");

  return (
    <div className="bg-gradient-to-r from-orange-600 via-pink-600 to-purple-700 text-white text-center py-2 px-4 text-sm font-semibold z-50 relative">
      🔥 ¡OFERTA LIMITADA! Descuentos hasta el 40% OFF · Termina en:{" "}
      <span className="font-mono bg-white/20 px-2 py-0.5 rounded ml-1">
        {pad(time.hours)}:{pad(time.minutes)}:{pad(time.seconds)}
      </span>
    </div>
  );
}
