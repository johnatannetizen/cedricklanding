const items = [
  { icon: "🛡️", text: "Garantía 12 meses" },
  { icon: "🚚", text: "Envío rápido a todo Colombia" },
  { icon: "💳", text: "Pago seguro y fácil" },
  { icon: "🔄", text: "Devoluciones sin complicaciones" },
  { icon: "📞", text: "Soporte 24/7 por WhatsApp" },
  { icon: "⭐", text: "+2.000 clientes satisfechos" },
];

export default function TrustBar() {
  return (
    <section className="bg-gradient-to-r from-[#0f0f1a] to-[#0a0a0f] border-y border-white/10 py-6 overflow-hidden relative">
      <div className="flex gap-12 animate-marquee whitespace-nowrap">
        {[...items, ...items].map((item, i) => (
          <div key={i} className="flex items-center gap-3 text-gray-300 shrink-0">
            <span className="text-2xl">{item.icon}</span>
            <span className="font-semibold text-sm">{item.text}</span>
            <span className="text-orange-500/50 ml-6">|</span>
          </div>
        ))}
      </div>
    </section>
  );
}
