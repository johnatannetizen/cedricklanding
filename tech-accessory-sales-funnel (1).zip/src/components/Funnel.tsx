const WA_NUMBER = "573016515466";

const steps = [
  {
    step: "01",
    icon: "🔍",
    title: "Elige tu producto",
    desc: "Explora nuestro catálogo y selecciona el accesorio tech que necesitas. Tenemos las mejores marcas y modelos disponibles.",
    color: "from-orange-500 to-pink-500",
  },
  {
    step: "02",
    icon: "💬",
    title: "Contáctanos por WhatsApp",
    desc: "Haz clic en el botón de compra y serás dirigido directamente a nuestro WhatsApp. Nuestros asesores responden en minutos.",
    color: "from-pink-500 to-purple-500",
  },
  {
    step: "03",
    icon: "💳",
    title: "Realiza tu pago",
    desc: "Aceptamos transferencias bancarias, Nequi, Daviplata y contra entrega. ¡Elige el método que más te convenga!",
    color: "from-purple-500 to-blue-500",
  },
  {
    step: "04",
    icon: "📦",
    title: "Recibe en tu puerta",
    desc: "Tu pedido será enviado de forma inmediata con seguimiento en tiempo real. Envíos a toda Colombia en 1-3 días hábiles.",
    color: "from-blue-500 to-green-500",
  },
];

const benefits = [
  { icon: "🎯", title: "Asesoría personalizada", desc: "Te ayudamos a elegir el producto ideal para tus necesidades y presupuesto." },
  { icon: "💰", title: "Mejor precio garantizado", desc: "Si encuentras el mismo producto más barato, te igualamos el precio." },
  { icon: "🛡️", title: "Garantía real", desc: "Todos nuestros productos tienen garantía de 12 meses contra defectos de fábrica." },
  { icon: "🔄", title: "Cambios fáciles", desc: "Si tu producto llega con algún defecto, lo cambiamos sin hacer preguntas." },
  { icon: "🚀", title: "Envío express", desc: "Despacho el mismo día para pedidos antes de las 2PM en ciudades principales." },
  { icon: "💎", title: "Productos originales", desc: "Solo trabajamos con distribuidores autorizados. Calidad 100% garantizada." },
];

export default function Funnel() {
  const waLink = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent("Hola Cedrick Tech, quiero hacer un pedido 🛒")}`;

  return (
    <>
      {/* How it works */}
      <section className="py-24 px-4 bg-gradient-to-b from-[#0a0a0f] via-[#0d0d1a] to-[#0a0a0f]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-purple-500/20 border border-purple-500/30 text-purple-400 text-sm font-semibold px-4 py-1.5 rounded-full mb-4">
              ⚡ Proceso Súper Simple
            </div>
            <h2 className="text-4xl sm:text-5xl font-black mb-4">
              <span className="text-white">¿Cómo </span>
              <span className="bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
                comprar?
              </span>
            </h2>
            <p className="text-gray-400 text-lg max-w-xl mx-auto">
              En solo 4 pasos tienes tu producto favorito en casa. ¡Es así de fácil!
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {steps.map((step, i) => (
              <div key={i} className="relative">
                {/* Connector line */}
                {i < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 left-full w-full h-0.5 bg-gradient-to-r from-white/20 to-transparent z-10 -translate-x-6" />
                )}
                <div className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:border-white/20 transition-all duration-300 text-center">
                  <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br ${step.color} text-3xl mb-4 shadow-lg`}>
                    {step.icon}
                  </div>
                  <div className={`text-xs font-black bg-gradient-to-r ${step.color} bg-clip-text text-transparent mb-2 tracking-widest`}>
                    PASO {step.step}
                  </div>
                  <h3 className="text-white font-bold text-lg mb-2">{step.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center">
            <a
              href={waLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500 text-white font-black text-lg px-10 py-4 rounded-full transition-all duration-200 shadow-2xl shadow-green-500/30 hover:scale-105"
            >
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
              ¡Empezar mi pedido ahora!
            </a>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="beneficios" className="py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-green-500/20 border border-green-500/30 text-green-400 text-sm font-semibold px-4 py-1.5 rounded-full mb-4">
              💎 ¿Por qué elegirnos?
            </div>
            <h2 className="text-4xl sm:text-5xl font-black mb-4">
              <span className="text-white">La diferencia </span>
              <span className="bg-gradient-to-r from-green-400 to-teal-500 bg-clip-text text-transparent">
                Cedrick Tech
              </span>
            </h2>
            <p className="text-gray-400 text-lg max-w-xl mx-auto">
              No somos solo una tienda. Somos tu aliado tecnológico de confianza.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {benefits.map((b, i) => (
              <div
                key={i}
                className="bg-gradient-to-b from-white/5 to-transparent border border-white/10 rounded-2xl p-6 hover:border-green-500/30 transition-all duration-300 hover:-translate-y-1 group"
              >
                <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-200">{b.icon}</div>
                <h3 className="text-white font-bold text-lg mb-2">{b.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>

          {/* Stats Row */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { num: "+5.000", label: "Clientes felices" },
              { num: "4.9⭐", label: "Calificación promedio" },
              { num: "12 meses", label: "De garantía" },
              { num: "< 5 min", label: "Tiempo de respuesta" },
            ].map((stat, i) => (
              <div key={i} className="text-center p-6 bg-white/5 rounded-2xl border border-white/10">
                <div className="text-3xl font-black text-white mb-1">{stat.num}</div>
                <div className="text-gray-400 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
