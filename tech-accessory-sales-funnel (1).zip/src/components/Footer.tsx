const WA_NUMBER = "573016515466";
const WA_LINK = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent("Hola Cedrick Tech, necesito información 💬")}`;

export default function Footer() {
  return (
    <footer className="bg-[#06060d] border-t border-white/10 pt-16 pb-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-pink-600 flex items-center justify-center">
                <span className="text-white font-black text-sm">CT</span>
              </div>
              <span className="font-black text-xl">
                <span className="text-white">CEDRICK</span>
                <span className="text-orange-500"> TECH</span>
              </span>
            </div>
            <p className="text-gray-500 text-sm leading-relaxed mb-4">
              Tu tienda de confianza para accesorios tecnológicos premium. Calidad garantizada, precios imbatibles y atención personalizada.
            </p>
            <div className="flex gap-3">
              <a
                href={WA_LINK}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-green-500/20 border border-green-500/30 text-green-400 text-sm font-semibold px-4 py-2 rounded-full hover:bg-green-500/30 transition-colors"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
                WhatsApp
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-white font-bold mb-4">Navegación</h4>
            <ul className="space-y-2 text-sm text-gray-500">
              {["Inicio", "Productos", "Beneficios", "Testimonios", "FAQ"].map((link) => (
                <li key={link}>
                  <a
                    href={`#${link.toLowerCase()}`}
                    className="hover:text-orange-400 transition-colors"
                  >
                    → {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-bold mb-4">Contacto</h4>
            <div className="space-y-3 text-sm text-gray-500">
              <div className="flex items-center gap-3">
                <span className="text-green-400 text-lg">📱</span>
                <div>
                  <p className="text-white font-semibold">WhatsApp</p>
                  <p>+57 301 651 5466</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-orange-400 text-lg">🕒</span>
                <div>
                  <p className="text-white font-semibold">Atención</p>
                  <p>Lun – Sáb: 8am – 8pm</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-blue-400 text-lg">🇨🇴</span>
                <div>
                  <p className="text-white font-semibold">Cobertura</p>
                  <p>Todo Colombia</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-white/10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-600">
          <p>© {new Date().getFullYear()} Cedrick Tech. Todos los derechos reservados.</p>
          <div className="flex gap-4">
            <span>🛡️ Compra segura</span>
            <span>🚚 Envíos Colombia</span>
            <span>✅ Garantía real</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
