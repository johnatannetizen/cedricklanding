import { useState } from "react";

const WA_NUMBER = "573016515466";

const faqs = [
  {
    q: "¿Cuáles son los métodos de pago disponibles?",
    a: "Aceptamos transferencias bancarias (Bancolombia, Davivienda, BBVA), Nequi, Daviplata y pago contra entrega en ciudades principales. Nuestro asesor te indicará el más conveniente para ti.",
  },
  {
    q: "¿A qué ciudades hacen envíos?",
    a: "Enviamos a toda Colombia a través de Servientrega, Coordinadora e Interrapidísimo. Medellín, Bogotá, Cali, Barranquilla, Bucaramanga, Pereira y todas las ciudades del país.",
  },
  {
    q: "¿Cuánto tiempo tarda el envío?",
    a: "Para ciudades principales (Bogotá, Medellín, Cali, Barranquilla): 1-2 días hábiles. Para municipios y ciudades intermedias: 2-4 días hábiles. Los pedidos realizados antes de las 2PM se despachan el mismo día.",
  },
  {
    q: "¿Los productos tienen garantía?",
    a: "¡Sí! Todos nuestros productos tienen garantía de 12 meses contra defectos de fábrica. Si tu producto presenta alguna falla, lo reemplazamos o te devolvemos el dinero. Así de simple.",
  },
  {
    q: "¿Los productos son originales?",
    a: "100%. Solo trabajamos con distribuidores autorizados y productos originales. Nunca vendemos réplicas o productos de baja calidad. Tu inversión está protegida.",
  },
  {
    q: "¿Cómo hago seguimiento a mi pedido?",
    a: "Una vez despachado tu pedido, te enviaremos por WhatsApp el número de guía de tu paquete para que puedas hacer seguimiento en tiempo real en el portal de la transportadora.",
  },
  {
    q: "¿Puedo hacer cambios o devoluciones?",
    a: "Sí. Si el producto llega con algún defecto o no corresponde a lo pedido, tienes 5 días hábiles para reportarlo y gestionamos el cambio o devolución sin costos adicionales.",
  },
  {
    q: "¿Tienen local físico?",
    a: "Actualmente operamos 100% en línea, lo que nos permite ofrecerte los mejores precios al reducir costos operativos. Toda la atención es por WhatsApp con respuesta en menos de 5 minutos.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <section id="faq" className="py-24 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-blue-500/20 border border-blue-500/30 text-blue-400 text-sm font-semibold px-4 py-1.5 rounded-full mb-4">
            ❓ Preguntas frecuentes
          </div>
          <h2 className="text-4xl sm:text-5xl font-black mb-4">
            <span className="text-white">¿Tienes </span>
            <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              dudas?
            </span>
          </h2>
          <p className="text-gray-400 text-lg">
            Resolvemos las preguntas más comunes. ¿Aún tienes preguntas? Escríbenos por WhatsApp.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className={`border rounded-2xl overflow-hidden transition-all duration-300 ${
                open === i
                  ? "border-orange-500/40 bg-orange-500/5"
                  : "border-white/10 bg-white/[0.02] hover:border-white/20"
              }`}
            >
              <button
                className="w-full flex items-center justify-between gap-4 px-6 py-5 text-left"
                onClick={() => setOpen(open === i ? null : i)}
              >
                <span className={`font-semibold text-sm sm:text-base ${open === i ? "text-orange-400" : "text-white"}`}>
                  {faq.q}
                </span>
                <svg
                  className={`w-5 h-5 flex-shrink-0 transition-transform duration-300 ${
                    open === i ? "rotate-180 text-orange-400" : "text-gray-400"
                  }`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              {open === i && (
                <div className="px-6 pb-5">
                  <p className="text-gray-400 text-sm leading-relaxed">{faq.a}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="text-center mt-10">
          <p className="text-gray-500 mb-4">¿Tu pregunta no está aquí?</p>
          <a
            href={`https://wa.me/${WA_NUMBER}?text=${encodeURIComponent("Hola Cedrick Tech, tengo una pregunta sobre sus productos 🤔")}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/15 border border-white/20 text-white font-bold px-8 py-3 rounded-full transition-all duration-200"
          >
            <svg className="w-5 h-5 text-green-400" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            Preguntar por WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}
